import { AddToCart } from './add-to-cart';

describe('AddToCart', () => {
  it('should create an instance', () => {
    expect(new AddToCart()).toBeTruthy();
  });
});
