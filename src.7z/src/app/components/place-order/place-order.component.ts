import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {
  // var cartItems=[];
  // cartItems=[];
  cart:any;
  value:any;
  constructor() { 
  //  console.log(11);
  var cartItems=[];
   var products=JSON.parse(localStorage.prod);
   var total=0;
   for(var i=0;i<products.length;i++){
     if(products[i].cart==true){
       cartItems.push(products[i]);
       total+=products[i].price;
     }
   }
   this.cart=cartItems;
   this.value=total;
  }

  ngOnInit(): void {
    console.log(33);
  }

}
